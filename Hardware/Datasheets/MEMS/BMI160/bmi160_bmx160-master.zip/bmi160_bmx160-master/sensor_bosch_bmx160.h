#ifndef SENSOR_BOS_BMI160_H__
#define SENSOR_BOS_BMI160_H__

#include <sensor.h>

int rt_hw_bmx160_init(const char *name, struct rt_sensor_config *cfg);

#endif
