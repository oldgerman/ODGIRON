/*
 * Page.hpp
 *
 *  Created on: 2021年4月20日
 *      Author: PSA
 */

#ifndef INC_PAGE_HPP_
#define INC_PAGE_HPP_
#include "Colum.hpp"
#include <list>
#include <vector>
#include "oled_init.h"
#include "font24x32numbers.h"
#include "Settings.h"
#include "Threads.hpp"
#include <Buttons.hpp>
#include "u8g2_simsun_9_fntodgironchinese.h"

#if 0
Colum columsHeatingPage[] = {
		Colum("焊接温度", systemSettings.SolderingTemp, "℃"),
		Colum("休眠温度", systemSettings.SleepTemp, "℃"),
		Colum("休眠时间", systemSettings.SleepTime, "S"),
		Colum("关断温度", systemSettings.ShutDownTemp, "℃"),
		Colum("关断时间", systemSettings.SleepTime, "S")
};

#else

#endif

#ifdef __cplusplus

class Page {
public:
	Page() {
	}
	Page(std::vector<Colum> *columVec) //默认指向的上一个Page是自己
	{
		_numColums = columVec->size();				//获取colums个数
		std::vector<Colum>::iterator columIter;
		for (columIter = columVec->begin();	columIter != columVec->end(); columIter++)
			_listColums.push_back(&(*columIter));	//std::list元素为Colum对象指针
		_itrColums = _listColums.begin(); //将选中的栏还原为第一个
	}
	virtual ~Page() {};

	static void flashPage() {
		for(;;)
		{
			//u8g2.clearBuffer();不要随便用clearbuffer，会导致显示乱码，u8g2是命令也在buffer里多次刷新的
			buttons = getButtonState();
			switch (buttons) {
			case BUTTON_F_SHORT:
				if(*(ptrPage->_itrColums) != ptrPage->_listColums.back())
				{
					ptrPage->_itrColums++;
					indexColums++;
				}
				break;
			case BUTTON_B_SHORT:
				if(ptrPage->_itrColums != ptrPage->_listColums.begin())
				{
					ptrPage->_itrColums--;
					indexColums--;
				}

				break;
			case BUTTON_OK_LONG:
				break;
			case BUTTON_OK_SHORT:
				if(ptrPage == homePage)	//仅对HomePage有效
				{
					ptrPage = (*ptrPage->_itrColums)->nextPage; //当前页面指针指向当前页面指针指向的Colum的下级菜单
					resetPageIndex(true);
				}
				else{
					columValAdjust((*ptrPage->_itrColums)->ptrAutoValue);
				}
					break;
			default:
				break;
			}
			bool timeOut = buttonStateTimeOut();
			if(buttons == BUTTON_B_LONG)	//是否返回主页
			{
				ptrPage = homePage;
				resetPageIndex(true);
				if(timeOut)
					break;
			}

			ptrPage->drawColums();
			u8g2.sendBuffer();
			GUIDelay();
			resetWatchdog();
		}
	}

	static void columValAdjust(AutoValue* ptrAutoValue) {
		uint32_t lastChange = xTaskGetTickCount();
		for (;;) {
			//u8g2.clearBuffer();	//保留上级for循环刷新的buffer，本节只刷新值
			buttons = getButtonState();
			if (buttons)
				lastChange = xTaskGetTickCount();
			AutoValue::buttonState = buttons;
			switch (buttons) {
			case BUTTON_B_LONG:
			case BUTTON_B_SHORT:
				(*ptrAutoValue)--;	//AutoValue::operator--()在内部判断buttons长按短按
				break;
			case BUTTON_F_LONG:
			case BUTTON_F_SHORT:
				(*ptrAutoValue)++;
				break;
			default:
				break;
			}

			if ((xTaskGetTickCount() - lastChange > 2000) || (buttons == BUTTON_OK_SHORT))
				return; // exit if user just doesn't press anything for a bit


			//drawColum();
			{
				//绘制反显矩形
				uint16_t y = *(indexColums.val);
				u8g2.setDrawColor(1);
				u8g2.drawBox(80, y, 48-7-2, 16);

				y += 1;
				u8g2.setDrawColor(0);
				drawNumber(113 - (ptrAutoValue->places) * 6, y,
						*(ptrAutoValue)->val,
						(ptrAutoValue)->places);

				u8g2.drawStr(82, y, "*");	//标记更改值
			}
			u8g2.sendBuffer();
			GUIDelay();
		}
	}


	void drawIcon() {
		//u8g2.setDrawColor(1);
		//u8g2.drawXBM(90, 0, 32, 32, _Icon);
	}

	void drawColums() {
		drawColum(*_itrColums, *(indexColums.val), 1);
		//绘制被选中colum上面的colum
		for (uint8_t i = indexColums.lower; i < *(indexColums.val);) {
			i += indexColums.shortSteps;
			drawColum(*_itrColums - (*(indexColums.val) - indexColums.lower) / indexColums.shortSteps + (i / indexColums.shortSteps) - 1,
					i - indexColums.shortSteps, 0);
		}
		//绘制被选中colum下面的colum
		for (uint8_t i = 0; i < indexColums.upper - *(indexColums.val);) {
			i += indexColums.shortSteps;
			drawColum(*_itrColums + (i / indexColums.shortSteps),
					*(indexColums.val) + i, 0);
		}

	}
	void drawColum(Colum *ptrColum, uint8_t y, bool selected) {
		//绘制反显矩形
		u8g2.setDrawColor(selected);
		u8g2.drawBox(0, y, 128, 16);
		u8g2.setDrawColor(!selected);

		//绘制栏名称字符,宋体UTF-8
		y += 2;	//偏移字符串y坐标
		u8g2.setFont( u8g2_simsun_9_fntodgironchinese);//12x12 pixels
		u8g2.drawUTF8(1, y, ptrColum->str);	//打印中文字符，编译器需要支持UTF-8编码，显示的字符串需要存为UTF-8编码
#if 1
		if(ptrColum->ptrAutoValue != nullptr)
		{
			//绘制栏详情字符
			y -= 1;	//偏移字符串y坐标
			u8g2.setFont(u8g2_font_unifont_tr);	//10x7 pixels
			if (!(*ptrColum->ptrAutoValue).valueIsBool()) {
				Page::drawNumber(113 - (ptrColum->ptrAutoValue->places) * 6, y,
						*(ptrColum->ptrAutoValue)->val,
						(ptrColum->ptrAutoValue)->places);
				u8g2.drawStr(119, y, ptrColum->unit);
			} else
				(*(ptrColum->ptrAutoValue)->val == true) ?
						u8g2.drawStr(96, y, "ON") : u8g2.drawStr(89, y, "OFF");
		}
#endif
	}

	static AutoValue indexColums;	//用于索引当前选中的colum在oled上的y坐标位置
	static Page *ptrPage;
	static Page *homePage;
	static void resetPageIndex(bool reset)
	{
		if(reset)
		{
			//强制指向第一个栏
			ptrPage->_itrColums = ptrPage->_listColums.begin();
			(*(indexColums.val) = 0);
		}
		else
		//尾端检查indexColums防止非法访问
		(*(ptrPage->_itrColums) == ptrPage->_listColums.back())
				? (*(indexColums.val) = indexColums.upper)
				: (*(indexColums.val) = 0);
	}
	static void drawNumber(uint8_t x, uint8_t y, uint16_t number, uint8_t places) {
		  char buffer[7] = {0};
		  //sprintf(buffer, "%06d" , number);
		  sprintf(buffer, "%6d" , number);
		  uint8_t cntFirstNum = 0;
		  uint8_t i = 0;
			while(i < 7)
			{
				if(buffer[i] != ' '){
					cntFirstNum = i;
					break;
				}
				++i;
			}
			uint8_t cntNum = 6 - cntFirstNum;
			u8g2.drawStr(x, y, buffer + cntFirstNum - (places - cntNum));
			//u8g2.drawUTF8(x, y, buffer + cntFirstNum - (places - cntNum));
		}
	static bool buttonStateTimeOut(){
		uint32_t previousState = xTaskGetTickCount();
		static uint32_t previousStateChange = xTaskGetTickCount();
		if ((previousState - previousStateChange) > 1000) {
			previousStateChange = previousState;
					return true;
		}
		return false;
	}
	//const uint8_t *font = u8g2_simsun_9_fntodgironchinese;
private:
	std::list<Colum*> _listColums;
	std::list<Colum*>::iterator _itrColums;
	//const uint8_t *_Icon;
	Page *_nextPage;
	Page *_prevPage;
	uint8_t _numColums;
};

extern Page pageHomePage;
#endif
#endif
