/*
 * Colum.hpp
 *
 *  Created on: 2021年4月20日
 *      Author: PSA
 */

#ifndef INC_COLUM_HPP_
#define INC_COLUM_HPP_
#include "stdint.h"
#include "Threads.hpp"	//提供buttons
#include "Buttons.hpp"	//提供buttons
class Page;
/**
 * 对于ON/OFF，则val传入bool，upper传入1， lower传入0
 * 待实现：值是否循环
 */
class AutoValue
{
public:
	//引用在定义时必须初始化
	AutoValue(){}
	AutoValue(uint16_t *Val, uint8_t Places, uint16_t Upper, uint16_t Lower, uint8_t ShortSteps, uint8_t LongSteps = 0, bool FollowButtonState = true)
	:val(Val), places(Places), upper(Upper), lower(Lower), shortSteps(ShortSteps), longSteps(LongSteps), followButtonState(FollowButtonState)
	{}
	virtual ~AutoValue() {}
	uint16_t operator++(int) {
		if(buttonState == BUTTON_F_SHORT || !followButtonState)
			return (*val + shortSteps <= upper) ? (*val += shortSteps) : *val;
		//++运算不足一个LongSteps时会自动变为upper
		else if(buttonState == BUTTON_F_LONG)
			if(upper - *val > longSteps)
				return *val += longSteps;
				else{
					*val = upper;
					return  (*val);
				}
		else
			return *val;
	}

	uint16_t & operator--(int) {
		if(buttonState == BUTTON_B_SHORT || !followButtonState)
			return (*val - shortSteps >= lower) ? (*val -= shortSteps) : *val;
		//--运算不足一个LongSteps时会自动变为lower
		else if(buttonState == BUTTON_B_LONG)
		{
			if(*val - lower > longSteps)
				return  *val -= longSteps;
			else{
					*val = lower;
					return  (*val);
			}
		}
		else
			return *val;
	}
	bool valueIsBool() {
		return (upper == 1 && lower == 0) ? 1 : 0;
	}
	uint16_t *val;	//待修改值
	uint8_t places;	//值的位数, //再说。若为浮点类则小数点占一位
	uint16_t upper;	//值的上限
	uint16_t lower;	//值的下限
	uint8_t shortSteps;	//短按值的步幅
	uint8_t longSteps;	//长按值的步幅
	bool followButtonState;	//是否跟随buttons状态，默认跟随，例外是Page::indexColums不跟随，会导致非法访问
	static ButtonState buttonState;
};

class Colum {
public:
	Colum(const char *Str,
			uint16_t *Val, uint8_t Places, uint16_t Upper, uint16_t Lower, uint8_t ShortSteps , uint8_t LongSteps = 0,
			const char *Uint = nullptr,
			bool X10 = false)
		:str(Str), unit(Uint),  x10(X10)
		{
			ptrAutoValue = new AutoValue(Val,  Places,  Upper,  Lower, ShortSteps, LongSteps);
			nextPage = nullptr;	//改值栏没有nextPage
		}
	Colum(const char *Str, Page* NextPage = nullptr)
	:str(Str), nextPage(NextPage)
	{
		ptrAutoValue = nullptr;
		unit = nullptr;

	}
	virtual ~Colum(){}

	//warning：str will be initialized after：确保成员在初始化列表中的出现顺序与在类中出现的顺序相同：
	const char * str;
	AutoValue *ptrAutoValue;
	const char * unit;
	Page* nextPage;
	Page* prevPage;
	bool x10;	//对于浮点数用X10倍
};

#endif /* INC_COLUM_HPP_ */
