/*
  Library for 1-d splines
  Copyright Ryan Michael
  https://github.com/kerinin/arduino-splines
  Licensed under the LGPLv3
*/


/*
 * README.md
# Arduino Splines
	This is a simple library for differnent types of 1-D Splines, written for the arduino environment.

## Usage
	Checkout the code
		git clone git://github.com/kerinin/arduino-splines.git ~/sketchbook/libraries/

	Add the library header to your code
		#include <spline.h>

	There are currently 4 types of spline interpolation available:

	Degree 0: This generates a step function. Between any two points the spline evaluates to the previous point
	Degree 1: Linear interpolation. Between any two points the spline returns the value of a straight line connecting the bounding points
	Hermite: Uses a Hermite spline to interpolate between the points. This method requires that you specify an array of tangent values m as well as the point arrays x and y.
	Catmull: Uses a Catmull-Rom spline to interpolate between the points. This is an easy way to obtain smooth interpolation - you don't need to specify the tangent points.
	Be aware that when using Catmull-Rom splines, the first and last points are not part of the spline - they are used to determine the tangency of the start and end of the spline. The spline itself starts at the second and second-to-last point.
	For all splines, values requested outside the defined spline bounds will return the value of either the start or end point.
	Using the library is fairly straightforward, simply pass it an array of points and use the value() function to interpolate between them. The spline points can be specified either when you instantiate the class or using the setPoints() and setDegree() functions.

# Arduino样条曲线
	这是为arduino环境编写的，用于不同类型的1-D样条曲线的简单库。
## 用法
	克隆代码
		git clone git://github.com/kerinin/arduino-splines.git ~/sketchbook/libraries/

	将库头添加到您的代码中
		#include <spline.h>

	当前有4种样条插值类型可用：
		度数0：这将生成一个阶跃函数。在任意两个点之间，样条曲线求值到上一个点
		1级：线性插值。在任意两个点之间，样条曲线返回连接边界点的直线的值
		Hermite：使用Hermite样条线在点之间进行插值。此方法要求您指定切线值数组m以及点数组x和y。
		Catmull：使用Catmull-Rom样条曲线在点之间进行插值。这是获得平滑插值的简便方法-无需指定切线点。

		请注意，在使用Catmull-Rom样条曲线时，第一个点和最后一个点都不是样条线的一部分-它们用于确定样条线起点和终点的切线。样条曲线本身从第二点到倒数第二个点开始。
		对于所有样条曲线，在已定义样条曲线边界之外请求的值将返回起点或终点的值。
		使用该库非常简单，只需将其传递给点数组并使用value（）函数在它们之间进行插值即可。可以在实例化类时指定样条点，也可以使用setPoints（） 和setDegree（）函数来指定样条点

			double x[10] = {0,1,2,3,4,5,6,7,8,9};
			double y[10] = {0,0,5,5,0,0,3,4,5,6};
			doulbe m[10] = {0,.5,.5,.5.,.25,.25,.75,1,1,1}

			Spline stepSpline(x,y,10,0);			//步幅
			Spline linearSpline(x,y,10,1);			//线性插值
			Spline hermiteSpline(x,y,m,10);       	// No neet to specify type since m passed
			Spline catmullsSpline(x,y,10,Catmull);

			stepSpline.value(5.5);    // => 0
			linearSpline.value(5.5);  // => 1.5

			Spline mySpline();
			mySpline.setPoints(x,y);
			mySpline.setDegree(1);

			mySpline.value(5.5);      // => 1.5
 */




#ifndef spline_h
#define spline_h
#define Hermite 10
#define Catmull 11

class Spline
{
  public:
    Spline( void );
    Spline( float x[], float y[], int numPoints, int degree = 1 );
    Spline( float x[], float y[], float m[], int numPoints );
    float value( float x );
    void setPoints( float x[], float y[], int numPoints );
    void setPoints( float x[], float y[], float m[], int numPoints );
    void setDegree( int degree );

  private:
    float calc( float, int);
    float* _x;
    float* _y;
    float* _m;
    int _degree;
    int _length;
    int _prev_point;

    float hermite( float t, float p0, float p1, float m0, float m1, float x0, float x1 );
    float hermite_00( float t );
    float hermite_10( float t );
    float hermite_01( float t );
    float hermite_11( float t );
    float catmull_tangent( int i );
};

#endif
