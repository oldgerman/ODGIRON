/*
 * Colum.cpp
 *
 *  Created on: 2021年4月20日
 *      Author: PSA
 */

#include <Colum.hpp>

ButtonState  AutoValue::buttonState;
