
#include "Page.hpp"
void   enterSettingsMenu()
{

	Page::flashPage();
}
