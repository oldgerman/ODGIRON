
#include "Page.hpp"
extern Page pageHeatingPage;

void   enterSettingsMenu()
{

	Page::flashPage(&pageHeatingPage);
}
