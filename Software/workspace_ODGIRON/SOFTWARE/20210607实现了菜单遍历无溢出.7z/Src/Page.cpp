/*
 * Page.cpp
 *
 *  Created on: 2021年4月20日
 *      Author: PSA
 */
/**
C++获取数组元素个数
C++中数组可分为堆区的数组和栈区的数组，对于两种数组C++都没有函数可以直接获取数组的元素的个数。

一、堆区的数组
堆区的数组是自己申请的，比如用new申请空间：
int* arr = new int[10];
堆区的数组不能计算出包含元素个数。

二、栈区的数组
栈区的数组是系统自动分配的，如：
	int arr[10] = { 1,2,3,4,5,6,7,8,9,0 };
栈区的数组可以通过以下两种方法得出元素的个数：
（1）
	int arr[10] = { 1,2,3,4,5,6,7,8,9,0 };
	auto diff = sizeof(arr)/sizeof(int);
（2）
这种方法需要所用编译器支持C++11,14
	int arr[10] = { 1,2,3,4,5,6,7,8,9,0 };
	int *pbeg = begin(arr);
	int *pend = end(arr);
	auto length = pend - pbeg;
 */
/**
终抱着“数组名就是指针”的错误信条到现在，可能是因为大学老师错误的讲解使我一直保留着这种误解。指针是C/C++语言的特色，
而数组名与指针有太多的相似，甚至很多时候，数组名可以作为指针使用，所以也难免在学习中将两者混淆。这里介绍下指针和数组名的区别:
指针和数组名占据的内存空间大小不一样，如下程序1：
char str[10];
char *pstr=str;
cout<<sizeof(str);
cout<<sizeof(pstr);
第一行输出结果是：40，第二行输出结果是：4
 */
#include <Page.hpp>

#if 0
Colum columsHeatingPage[] = {
		Colum("SolderingC", 	(uint16_t *)&systemSettings.SolderingTemp, 3, 420, 0, 1, "℃"),
		Colum("SleepingC", 	(uint16_t *)&systemSettings.SleepTemp, 3, 250, 0, 1, 		"℃"),
		Colum("SleepingT", 	(uint16_t *)&(systemSettings.SleepTime), 2, 60, 0, 1, 		"S"),
		Colum("Shut DownC", 	(uint16_t *)&systemSettings.ShutDownTemp, 3, 200, 0, 1, 	"℃"),
		Colum("Shut DownS",  (uint16_t *)&(systemSettings.ShutDownTime), 2, 60, 0, 1, 		"S")
};
#else
/**
 * C++对象数组构造函数
 * 要使用需要多个参数的构造函数，则初始化项必须釆用函数调用的形式。
 * 例如，来看下面的定义语句，它为 3 个 Circle 对象的每一个调用 3 个参数的构造函数：
 * Circle circle[3] = {Circle(4.0, 2, 1),Circle(2.0, 1, 3),Circle (2.5, 5, -1) };
 * 没有必要为数组中的每个对象调用相同的构造函数。例如，以下语句也是合法的：
 * Circle circle [3] = { 4.0,Circle (2.0, 1, 3),2.5 };
 */
/**
 * array对象和数组存储在相同的内存区域（栈）中，vector对象存储在自由存储区（堆）
 */
std::vector<Colum> columsHeatingPage= {
		Colum("B", 	(uint16_t *)&systemSettings.SleepTemp, 3, 250, 0, 1, 		"C"),
		Colum("C", 	(uint16_t *)&(systemSettings.SleepTime), 2, 60, 0, 1, 		"S"),
		Colum("D", 	(uint16_t *)&systemSettings.ShutDownTemp, 3, 200, 0, 1, 	"C"),
		Colum("G", 	(uint16_t *)&systemSettings.SleepTemp, 3, 250, 0, 1, 		"C"),
		Colum("H", 	(uint16_t *)&(systemSettings.SleepTime), 2, 60, 0, 1, 		"S"),
		Colum("I", 	(uint16_t *)&systemSettings.ShutDownTemp, 3, 200, 0, 1, 	"C"),
		Colum("J",  (uint16_t *)&(systemSettings.ShutDownTime), 2, 60, 0, 1, 		"S")
};
#endif


Page pageHeatingPage(&columsHeatingPage, solderingPageIcon);


uint16_t indexColumsValue = 0;
AutoValue Page::indexColums(&indexColumsValue, 2, 22, 0, 11);
