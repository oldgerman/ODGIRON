/*
 * Page.hpp
 *
 *  Created on: 2021年4月20日
 *      Author: PSA
 */

#ifndef INC_PAGE_HPP_
#define INC_PAGE_HPP_
#include "Colum.hpp"
#include <list>
#include <vector>
#include "oled_init.h"
#include "font24x32numbers.h"
#include "Settings.h"
#include "Threads.hpp"
#include <Buttons.hpp>

#if 0
Colum columsHeatingPage[] = {
		Colum("焊接温度", systemSettings.SolderingTemp, "℃"),
		Colum("休眠温度", systemSettings.SleepTemp, "℃"),
		Colum("休眠时间", systemSettings.SleepTime, "S"),
		Colum("关断温度", systemSettings.ShutDownTemp, "℃"),
		Colum("关断时间", systemSettings.SleepTime, "S")
};

#else

#endif

#ifdef __cplusplus

template<typename baseIter>
class CircularIterator {
public:
	CircularIterator() {
	}
	;
	CircularIterator(baseIter begin, baseIter end, baseIter current) :
			_current(current), _begin(begin), _end(end) {
	}
	baseIter& operator++(int) {
		++_current;
		if (_current == _end) {
			_current = _begin;
		}
		return _current;
	}
	baseIter& operator--(int) {
		--_current;
		if (_current == _begin) {
			_current = _end;
		}
		return _current;
	}

	baseIter _current;
	baseIter _begin;
	baseIter _end;

};


class Page {
public:
	Page() {
	}
	Page(std::vector<Colum> *columVec, const uint8_t *Icon, Page *prevPage = nullptr) //默认指向的上一个Page是自己
	:
			_Icon(Icon), _prevPage(prevPage) {


		//获取colums个数

		_numColums = columVec->size();//_numColums = 7


		std::vector<Colum>::iterator columIter;
		for (columIter = columVec->begin();	columIter != columVec->end(); columIter++)
			_listColums.push_back(&(*columIter));	//向list类传对象指针


		ptrColums = &(columVec->front());
		_selectedColums = ptrColums;	//选中的栏为第一个
	}
	virtual ~Page() {};
	static void flashPage(Page *ptrPage) {
		for(;;)
		{
			u8g2.clearBuffer();
			buttons = getButtonState();
			switch (buttons) {

			case BUTTON_F_SHORT:
				if(ptrPage->_selectedColums != (ptrPage->ptrColums + ptrPage->_numColums - 1))
				{
					ptrPage->_selectedColums++;
					indexColums++;
				}
				break;
			case BUTTON_B_SHORT:
				if(ptrPage->_selectedColums != ptrPage->_listColums.front())
				{
					ptrPage->_selectedColums--;
					indexColums--;
				}
				break;
			case BUTTON_OK_LONG:
				//ptrPage = page->getBackPrevoiusPage();
				break;
			default:
				break;
			}
			ptrPage->drawColums();
			ptrPage->drawIcon();
			usb_printf("_numColums = %d\r\n", ptrPage->_numColums);
			u8g2.sendBuffer();
			GUIDelay();
			if(buttons == BUTTON_B_LONG)
				break;
		}
	}
	void drawIcon() {
		u8g2.setDrawColor(1);
		u8g2.drawXBM(90, 0, 32, 32, _Icon);
	}
	Page* getBackPrevoiusPage() {
		_selectedColums = _listColums.front(); //将选中的栏还原为第一个
		return _prevPage;
	}
	void drawColums() {
#if 1
		drawColum(_selectedColums, *(indexColums.val), 1);
		//_selectedColums +=2;
		//绘制被选中colum上面的colum
		for (uint8_t i = indexColums.lower; i < *(indexColums.val);) {
			i += indexColums.steps;
			drawColum(
					_selectedColums
							- (*(indexColums.val) - indexColums.lower)
									/ indexColums.steps
							+ (i / indexColums.steps) - 1,
					i - indexColums.steps, 0);
		}
#if 1

		//绘制被选中colum下面的colum
		for (uint8_t i = 0; i < indexColums.upper - *(indexColums.val);) {
			i += indexColums.steps;
			drawColum(_selectedColums + (i / indexColums.steps),
					*(indexColums.val) + i, 0);
		}

#endif
		//绘制被选中的colum

#endif

	}
	void drawColum(Colum *ptrColum, uint8_t y, bool selected) {
		u8g2.setDrawColor(selected);
		u8g2.drawBox(0, y, 91, 10);
		u8g2.setDrawColor(!selected);
		u8g2.drawStr(1, y, ptrColum->str);

		if (!(*ptrColum->ptrAutoValue).valueIsBool()) {
			drawNumber(82 - (ptrColum->ptrAutoValue->places) * 6, y,
					*(ptrColum->ptrAutoValue)->val,
					(ptrColum->ptrAutoValue)->places);
			u8g2.drawStr(82, y, ptrColum->unit);
		} else
			(*(ptrColum->ptrAutoValue)->val == true) ?
					u8g2.drawStr(76, y, "ON") : u8g2.drawStr(69, y, "OFF");
	}
	static AutoValue indexColums;	//用于索引当前选中的colum在oled上的y坐标位置
	//const uint8_t *font = u8g2_simsun_9_fntodgironchinese;
private:
	const uint8_t *_Icon;
	Page *_prevPage;
	Colum *_selectedColums;
	Colum *ptrColums;
	std::list<Colum*> _listColums;
	std::list<Colum*>::iterator _itr;
	//CircularIterator<std::list<Colum *>::iterator> _circularIterator;
	uint8_t _numColums;
};

extern Page pageHeatingPage;

#endif
#endif
