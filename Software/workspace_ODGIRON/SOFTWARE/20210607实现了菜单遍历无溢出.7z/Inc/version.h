/**
 * Firmware build version - format: xx.yy.zzzzzz
 * x: Major  -  y: Minor  -  z: git short hash generated automaticaly from git
 * i.e.: BUILD_VERSION = 'Rel. v2.08' --> Will generated to: 'v2.08.1a2b3c4'
 */

#define BUILD_VERSION "v2.14"
