/*
 * Colum.hpp
 *
 *  Created on: 2021年4月20日
 *      Author: PSA
 */

#ifndef INC_COLUM_HPP_
#define INC_COLUM_HPP_
#include "stdint.h"

/**
 * 对于ON/OFF，则val传入bool，upper传入1， lower传入0
 */
class AutoValue
{
public:
	//引用在定义时必须初始化
	AutoValue(){}
	AutoValue(uint16_t *Val, uint8_t Places, uint16_t Upper, uint16_t Lower, uint8_t Steps)
	:val(Val), places(Places), upper(Upper), lower(Lower),steps(Steps)
	{}
	virtual ~AutoValue() {}
	uint16_t operator++(int) {
		return (*val + steps <= upper) ? (*val += steps) : *val;
	}

	uint16_t & operator--(int) {
		return (*val - steps >= lower) ? (*val -= steps) : *val;
	}
	bool valueIsBool() {
		return (upper == 1 && lower == 0) ? 1 : 0;
	}
	uint16_t *val;	//待修改值
	uint8_t places;	//值的位数, //再说。若为浮点类则小数点占一位
	uint16_t upper;	//值的上限
	uint16_t lower;	//值的下限
	uint8_t steps;	//值的步幅
};

class Colum {
public:
	Colum(const char *Str,
			uint16_t *Val, uint8_t Places, uint16_t Upper, uint16_t Lower, uint8_t Steps ,
			const char *Uint,
			bool X10 = false)
		:str(Str), unit(Uint), x10(X10)
		{
			ptrAutoValue = new AutoValue(Val,  Places,  Upper,  Lower, Steps);
		}
	virtual ~Colum(){}

	//warning：str will be initialized after：确保成员在初始化列表中的出现顺序与在类中出现的顺序相同：
	const char * str;
	AutoValue *ptrAutoValue;
	const char * unit;
	bool x10;	//对于浮点数用X10倍
};

#endif /* INC_COLUM_HPP_ */
