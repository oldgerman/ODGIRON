/*
 * fontsTable.h
 *
 *  Created on: Feb 23, 2021
 *      Author: 29209
 */

#ifndef FONTTABLES_H_
#define FONTTABLES_H_

#include "BSP.h"

extern const uint8_t USER_FONT_12[];
extern const uint8_t USER_FONT_6x8[];
//extern const uint8_t ExtraFontChars[];	//defined in HARDWARE/Inc/Font.h

#endif /* FONTTABLES_H_ */
